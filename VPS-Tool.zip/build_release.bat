@echo off
setlocal
cd /d "%~dp0"
title Build VPS Tool V25
echo === BUILD VPS TOOL V25 ===
echo Folder: %CD%
if not exist "VPS-Tool.csproj" (
  echo ERROR: VPS-Tool.csproj khong nam cung thu muc voi build_release.bat
  pause
  exit /b 1
)
dotnet restore "VPS-Tool.csproj"
if errorlevel 1 goto :err
dotnet publish "VPS-Tool.csproj" -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true /p:EnableCompressionInSingleFile=false /p:DebugType=None /p:DebugSymbols=false
if errorlevel 1 goto :err
set "EXE=%CD%\bin\Release\net8.0-windows\win-x64\publish\VPS-Tool.exe"
if not exist "%EXE%" goto :err

echo Creating Desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$exe=$env:EXE; $desktop=[Environment]::GetFolderPath('Desktop'); $lnk=Join-Path $desktop 'VPS Tool.lnk'; $w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut($lnk); $s.TargetPath=$exe; $s.WorkingDirectory=[IO.Path]::GetDirectoryName($exe); $s.IconLocation=$exe+',0'; $s.Save()"
if errorlevel 1 (
  echo WARNING: Build OK but Desktop shortcut could not be created.
) else (
  echo Shortcut: %%USERPROFILE%%\Desktop\VPS Tool.lnk
)
echo.
echo BUILD OK
echo EXE: %EXE%
pause
exit /b 0
:err
echo.
echo BUILD ERROR - gui nguyen phan error cho ChatGPT.
pause
exit /b 1
