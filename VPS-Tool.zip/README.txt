VPS Tool V25
- Build: chạy build_release.bat bằng .NET 8 SDK.
- EXE portable: bin\Release\net8.0-windows\win-x64\publish\VPS-Tool.exe
- Build xong tự tạo shortcut VPS Tool ngoài Desktop.
- File tải/giải nén của tool: %USERPROFILE%\Downloads\VPS-Tool
- App đã có trên máy: tên màu cam, checkbox vẫn dùng để chọn cài.
- Chuột phải app đã có > Gỡ cài đặt.
- Proxy Sport: giải nén extension, mở Chrome Extensions + thư mục chứa manifest.json để Load unpacked.
