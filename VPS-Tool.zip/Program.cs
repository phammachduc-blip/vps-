﻿using System.Diagnostics;
using System.IO.Compression;
using System.Net.Http.Json;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text.Json;
using Microsoft.Win32;
using SharpZipFile = ICSharpCode.SharpZipLib.Zip.ZipFile;
using SharpZipEntry = ICSharpCode.SharpZipLib.Zip.ZipEntry;

namespace VPSTool;
static class Program {
 [STAThread] static void Main(){
  string log=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"VPS-Tool","VPS-Tool-error.log");
  try{Directory.CreateDirectory(Path.GetDirectoryName(log)!);File.AppendAllText(log,$"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] START V25 | {Environment.OSVersion} | {RuntimeInformation.FrameworkDescription}\r\n");}catch{}
  try{
   AppDomain.CurrentDomain.UnhandledException+=(s,e)=>WriteCrash(log,e.ExceptionObject as Exception??new Exception(e.ExceptionObject?.ToString()));
   Application.ThreadException+=(s,e)=>WriteCrash(log,e.Exception);
   Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
   ApplicationConfiguration.Initialize();
   using var l=new LockForm(); if(l.ShowDialog()!=DialogResult.OK)return;
   Application.Run(new MainForm());
  }catch(Exception ex){WriteCrash(log,ex);try{MessageBox.Show("VPS Tool không thể khởi động.\n\n"+ex.Message+"\n\nLog: "+log,"VPS Tool - Lỗi khởi động",MessageBoxButtons.OK,MessageBoxIcon.Error);}catch{}}
 }
 static void WriteCrash(string path,Exception ex){try{File.AppendAllText(path,$"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}\r\n\r\n");}catch{}}
}
class LockForm:Form{
 readonly TextBox code=new(){UseSystemPasswordChar=true};
 public LockForm(){SuspendLayout();Text="VPS - Mở khóa";ClientSize=new(390,145);StartPosition=FormStartPosition.CenterScreen;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;AutoScaleMode=AutoScaleMode.Dpi;var lbl=new Label{Text="Mã mở khóa",Left=28,Top=30,Width=105,Height=26,TextAlign=ContentAlignment.MiddleLeft};code.SetBounds(140,28,215,27);Controls.Add(lbl);Controls.Add(code);var b=new Button{Text="Mở VPS",Left=140,Top=76,Width=130,Height=34};b.Click+=(_,_)=>{if(code.Text=="168168")DialogResult=DialogResult.OK;else MessageBox.Show("Sai mã mở khóa.","VPS");};Controls.Add(b);AcceptButton=b;ResumeLayout(false);}
}
record AppItem(string name,string version,string url,string type,string? password=null); record AppConfig(List<AppItem> apps);
class MainForm:Form{
 const string AppsUrl="https://raw.githubusercontent.com/phammachduc-blip/vps-/main/apps.json";
 readonly HttpClient http=new(){Timeout=TimeSpan.FromMinutes(10)}; readonly CheckedListBox appList=new(){CheckOnClick=true}; readonly Label status=new(){AutoSize=true}; readonly Label metrics=new(){AutoSize=true}; readonly System.Windows.Forms.Timer timer=new(){Interval=2000}; readonly System.Windows.Forms.Timer autoTimeTimer=new(){Interval=3600000}; bool loadingChecks; readonly HashSet<string> installedItems=new(StringComparer.OrdinalIgnoreCase); List<AppItem> online=[]; ulong lastIdle,lastKernel,lastUser,lastRx,lastTx; DateTime lastNet=DateTime.Now;
 readonly Color blue=Color.FromArgb(30,120,235);
 readonly Dictionary<string,string> webApps=new(StringComparer.OrdinalIgnoreCase){
  ["iBet"]="https://www.14186vv.com/b/vn",
  ["Agent iBet"]="https://www.fika88.com/",
  ["SBOBET"]="https://www.sbobet.com/",
  ["Agent SBOBET"]="https://agent.sbobet.com/"
 };
 string WebAppConfigPath=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"VPS-Tool","webapps.json");
 public MainForm(){http.DefaultRequestHeaders.UserAgent.ParseAdd("VPS-Tool/25.0");Text="VPS";ClientSize=new(1180,660);MinimumSize=new(1196,699);MaximumSize=new(1196,699);StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(10,25,58);ForeColor=Color.White;AutoScroll=false;AutoScaleMode=AutoScaleMode.None;FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;LoadWebAppLinks();Build();SetupAppContextMenu();appList.DrawMode=DrawMode.OwnerDrawFixed;appList.DrawItem+=DrawAppItem;Shown+=async(_,_)=>{await LoadApps();LoadToggleStates();};timer.Tick+=(_,_)=>RefreshStatus();timer.Start();autoTimeTimer.Tick+=(_,_)=>SyncTime();}
 Label L(string t,int x,int y,int s=10,bool bold=false){var l=new Label{Text=t,Left=x,Top=y,AutoSize=true,ForeColor=Color.White,Font=new Font("Segoe UI",s,bold?FontStyle.Bold:FontStyle.Regular)};Controls.Add(l);return l;}
 Button B(string t,int x,int y,int w=145){var b=new Button{Text=t,Left=x,Top=y,Width=w,Height=38,BackColor=blue,ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",9)};b.FlatAppearance.BorderSize=0;Controls.Add(b);return b;}
 GroupBox G(string title,int x,int y,int w,int h){var g=new GroupBox{Text=title,Left=x,Top=y,Width=w,Height=h,ForeColor=Color.White,BackColor=Color.FromArgb(5,35,67),Font=new Font("Segoe UI",11,FontStyle.Bold),Padding=new Padding(12)};Controls.Add(g);return g;}
 Button GB(GroupBox g,string t,int x,int y,int w,int h=42){var b=new Button{Text=t,Left=x,Top=y,Width=w,Height=h,BackColor=blue,ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",9)};b.FlatAppearance.BorderSize=0;g.Controls.Add(b);return b;}
 CheckBox GC(GroupBox g,string name,string text,int x,int y,int w=210){var c=new CheckBox{Name=name,Text=text,Left=x,Top=y,Width=w,Height=28,ForeColor=Color.White,BackColor=Color.Transparent,Font=new Font("Segoe UI",9)};c.CheckedChanged+=ToggleChanged;c.CheckedChanged+=(_,_)=>UpdateToggleColor(c);g.Controls.Add(c);return c;}
 void Build(){
  SuspendLayout();
  ClientSize=new Size(1180,660);MinimumSize=MaximumSize=new Size(1196,699);
  var header=new Panel{Left=0,Top=0,Width=1180,Height=76,BackColor=Color.FromArgb(5,35,67)};Controls.Add(header);
  try{var pb=new PictureBox{Left=28,Top=8,Width=60,Height=60,SizeMode=PictureBoxSizeMode.Zoom,Image=Icon.ExtractAssociatedIcon(Application.ExecutablePath)?.ToBitmap()};header.Controls.Add(pb);}catch{}
  // One-line header: large red VPS + smaller white TOOL AUTO. No subtitle, so it cannot overlap.
  header.Controls.Add(new Label{Text="VPS",Left=405,Top=10,Width=170,Height=56,TextAlign=ContentAlignment.MiddleRight,ForeColor=Color.Red,Font=new Font("Segoe UI",30,FontStyle.Bold)});
  header.Controls.Add(new Label{Text="TOOL AUTO",Left=580,Top=19,Width=230,Height=42,TextAlign=ContentAlignment.MiddleLeft,ForeColor=Color.White,Font=new Font("Segoe UI",17,FontStyle.Bold)});
  header.Controls.Add(new Label{Text="Nhanh - Đơn giản - Hiệu quả",Left=900,Top=24,Width=250,Height=28,TextAlign=ContentAlignment.MiddleRight,ForeColor=Color.Gainsboro,Font=new Font("Segoe UI",9.5f)});

  var quick=G("TÁC VỤ NHANH",14,80,1152,74);
  string[] acts={"Tối ưu RAM","Tối ưu CPU","Khởi động lại","Task Manager","Xóa TEMP"};
  string[] kinds={"chip","bars","refresh","monitor","trash"};
  for(int i=0;i<acts.Length;i++){var b=GB(quick,acts[i],12+i*224,27,214,36);StyleIconButton(b,kinds[i]);WireQuick(b,acts[i]);}

  var win=G("BẬT / TẮT WINDOWS",14,162,440,280);
  AddToggle(win,"UAC","UAC","shield",14,38);AddToggle(win,"Hiện icon Tray","Hiện icon Tray","tray",220,38);
  AddToggle(win,"Firewall","Firewall","grid",14,82);AddToggle(win,"Taskbar nhỏ","Taskbar nhỏ","taskbar",220,82);
  AddToggle(win,"Windows Update","Windows Update","refresh",14,126);AddToggle(win,"System Restore","System Restore","restore",220,126);
  AddToggle(win,"Cho phép Sleep","Cho phép Sleep","moon",14,170);AddToggle(win,"Tối ưu RDP","Tối ưu RDP","monitor",220,170);

  var apps=G("CÀI PHẦN MỀM",466,162,326,280);
  appList.SetBounds(12,32,302,186);appList.BackColor=Color.FromArgb(13,51,84);appList.ForeColor=Color.White;appList.BorderStyle=BorderStyle.FixedSingle;appList.Font=new Font("Segoe UI",9.2f);apps.Controls.Add(appList);
  var install=GB(apps,"Tải & cài",12,226,302,40);StyleIconButton(install,"download");install.Click+=async(_,_)=>await InstallSelected();

  var manage=G("QUẢN LÝ VPS",804,162,362,280);
  ManageField(manage,"Tài khoản",12,36,"Tên mới",v=>RenameUser(v),false,"user");
  ManagePasswordField(manage,"Mật khẩu",12,76,"Mật khẩu mới","key");
  var rdpNow=new Label{Name="RdpNow",Text=$"Port RDP hiện tại:  {GetRdp()}",Left=48,Top=116,Width=292,Height=25,ForeColor=Color.Gold,Font=new Font("Segoe UI",9.2f,FontStyle.Bold)};manage.Controls.Add(rdpNow);manage.Controls.Add(IconBox("monitor",14,114));
  ManageField(manage,"Đổi RDP",12,146,"VD: 8888",v=>{ChangeRdp(v);rdpNow.Text=$"Port RDP hiện tại:  {GetRdp()}";},false,"swap");
  var dm=GB(manage,"Ổ đĩa",12,194,160,40);StyleIconButton(dm,"disk");dm.Click+=(_,_)=>Run("diskmgmt.msc","");
  var ext=GB(manage,"Mở rộng C:",180,194,168,40);StyleIconButton(ext,"diskplus");ext.Click+=(_,_)=>ExtendC();
  var cd=GB(manage,"Tạo D:",12,238,160,32);StyleIconButton(cd,"plus");cd.Click+=(_,_)=>CreateD();

  var st=G("TRẠNG THÁI HỆ THỐNG",14,450,646,128);
  // Three icons align exactly with the three metric rows.
  metrics.SetBounds(64,30,552,88);metrics.Font=new Font("Segoe UI",9.2f);metrics.ForeColor=Color.White;st.Controls.Add(metrics);
  st.Controls.Add(IconBox("chip",18,31));st.Controls.Add(IconBox("bars",18,58));st.Controls.Add(IconBox("monitor",18,85));

  var settings=G("APP SETTING",672,450,494,128);
  var sync=GB(settings,"Đồng bộ giờ",70,32,190,38);StyleIconButton(sync,"clock");sync.Click+=(_,_)=>SyncTime();settings.Controls.Add(IconBox("clock",18,33));
  var auto=new CheckBox{Name="AutoTime",Text="Tự động cập nhật giờ",Left=276,Top=37,Width=204,Height=28,ForeColor=Color.White,Font=new Font("Segoe UI",8.7f)};auto.CheckedChanged+=(_,_)=>{if(loadingChecks)return;autoTimeTimer.Enabled=auto.Checked;if(auto.Checked)SyncTime();};settings.Controls.Add(auto);
  var chrome=new CheckBox{Name="ChromeDefault",Text="Đặt Chrome làm trình duyệt mặc định",Left=70,Top=72,Width=405,Height=26,ForeColor=Color.White,Font=new Font("Segoe UI",8.7f)};chrome.CheckedChanged+=(_,_)=>{if(loadingChecks||!chrome.Checked)return;Run("cmd.exe","/c start ms-settings:defaultapps");MessageBox.Show("Windows bảo vệ lựa chọn trình duyệt mặc định. Hãy chọn Google Chrome trong trang Default apps vừa mở.","VPS");};settings.Controls.Add(chrome);settings.Controls.Add(IconBox("globe",18,70));
  EnsureProxyConfig();
  var getProxy=new CheckBox{Name="GetProxy",Text="Lấy Proxy",Left=70,Top=98,Width=95,Height=25,ForeColor=Color.White,Font=new Font("Segoe UI",8.7f)};settings.Controls.Add(getProxy);
  var proxyVn=GB(settings,"Proxy VN",170,94,135,28);var proxyUsa=GB(settings,"Proxy USA",315,94,135,28);proxyVn.Font=proxyUsa.Font=new Font("Segoe UI",8.5f);proxyVn.Visible=proxyUsa.Visible=false;
  getProxy.CheckedChanged+=(_,_)=>{proxyVn.Visible=proxyUsa.Visible=getProxy.Checked;};proxyVn.Click+=(_,_)=>CopyProxy("VN","Proxy VN");proxyUsa.Click+=(_,_)=>CopyProxy("USA","Proxy USA");

  // Footer is fully inside the client area and includes the latest-action log.
  var footer=new Panel{Left=0,Top=586,Width=1180,Height=62,BackColor=Color.FromArgb(5,35,67)};Controls.Add(footer);
  status.SetBounds(18,10,120,30);status.ForeColor=Color.Gold;status.Font=new Font("Segoe UI",9);footer.Controls.Add(status);
  var log=new Label{Name="LastLog",Text="Log: Chưa có thao tác.",Left=140,Top=10,Width=710,Height=30,ForeColor=Color.Gainsboro,Font=new Font("Segoe UI",9),TextAlign=ContentAlignment.MiddleLeft};footer.Controls.Add(log);
  var extLink=new LinkLabel{Name="ChromeExtensionsLink",Text="Mở trang Chrome Extensions",Left=140,Top=36,Width=220,Height=22,Visible=false,LinkColor=Color.DeepSkyBlue,ActiveLinkColor=Color.Orange,VisitedLinkColor=Color.DeepSkyBlue,Font=new Font("Segoe UI",9,FontStyle.Underline)};extLink.LinkClicked+=async(_,_)=>await OpenChromeExtensions();footer.Controls.Add(extLink);
  var foot=new Label{Text="VPS Tool v25.0   |   2026",Left=890,Top=10,Width=260,Height=30,TextAlign=ContentAlignment.MiddleRight,ForeColor=Color.Gainsboro,Font=new Font("Segoe UI",9)};footer.Controls.Add(foot);
  RefreshStatus();ResumeLayout(false);
 }
 void AddToggle(GroupBox g,string name,string text,string kind,int x,int y){var c=GC(g,name,text,x+42,y,170);c.Font=new Font("Segoe UI",9);g.Controls.Add(IconBox(kind,x+8,y+2));}
 PictureBox IconBox(string kind,int x,int y){return new PictureBox{Left=x,Top=y,Width=28,Height=28,SizeMode=PictureBoxSizeMode.CenterImage,Image=MakeIcon(kind,24)};}
 void StyleIconButton(Button b,string kind){b.Image=MakeIcon(kind,22);b.ImageAlign=ContentAlignment.MiddleLeft;b.TextImageRelation=TextImageRelation.ImageBeforeText;b.Padding=new Padding(8,0,4,0);b.Font=new Font("Segoe UI",9.5f);}
 Bitmap MakeIcon(string kind,int size){var bmp=new Bitmap(size,size);using var g=Graphics.FromImage(bmp);g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;using var p=new Pen(Color.White,2.2f);using var br=new SolidBrush(Color.White);float s=size;
  if(kind=="bars"){g.FillRectangle(br,s*.12f,s*.62f,s*.18f,s*.25f);g.FillRectangle(br,s*.40f,s*.42f,s*.18f,s*.45f);g.FillRectangle(br,s*.68f,s*.18f,s*.18f,s*.69f);} 
  else if(kind=="monitor"){g.DrawRectangle(p,s*.10f,s*.16f,s*.80f,s*.55f);g.DrawLine(p,s*.5f,s*.71f,s*.5f,s*.86f);g.DrawLine(p,s*.30f,s*.86f,s*.70f,s*.86f);} 
  else if(kind=="clock"){g.DrawEllipse(p,s*.12f,s*.12f,s*.76f,s*.76f);g.DrawLine(p,s*.5f,s*.5f,s*.5f,s*.27f);g.DrawLine(p,s*.5f,s*.5f,s*.68f,s*.58f);} 
  else if(kind=="download"){g.DrawLine(p,s*.5f,s*.10f,s*.5f,s*.62f);g.DrawLine(p,s*.28f,s*.43f,s*.5f,s*.65f);g.DrawLine(p,s*.72f,s*.43f,s*.5f,s*.65f);g.DrawLine(p,s*.18f,s*.82f,s*.82f,s*.82f);} 
  else if(kind=="trash"){g.DrawRectangle(p,s*.27f,s*.30f,s*.46f,s*.55f);g.DrawLine(p,s*.20f,s*.25f,s*.80f,s*.25f);g.DrawLine(p,s*.38f,s*.16f,s*.62f,s*.16f);} 
  else if(kind=="disk"||kind=="diskplus"){g.DrawRectangle(p,s*.12f,s*.22f,s*.76f,s*.58f);g.DrawLine(p,s*.12f,s*.62f,s*.88f,s*.62f);g.FillEllipse(br,s*.68f,s*.68f,3,3);if(kind=="diskplus"){g.DrawLine(p,s*.72f,s*.08f,s*.72f,s*.34f);g.DrawLine(p,s*.59f,s*.21f,s*.85f,s*.21f);}} 
  else if(kind=="grid"){for(int a=0;a<3;a++)for(int b=0;b<3;b++)g.FillRectangle(br,s*(.16f+a*.25f),s*(.16f+b*.25f),s*.15f,s*.15f);} 
  else if(kind=="taskbar"||kind=="tray"){g.DrawRectangle(p,s*.10f,s*.20f,s*.80f,s*.60f);g.FillRectangle(br,s*.12f,s*.66f,s*.76f,s*.12f);} 
  else if(kind=="plus"){g.DrawLine(p,s*.5f,s*.18f,s*.5f,s*.82f);g.DrawLine(p,s*.18f,s*.5f,s*.82f,s*.5f);} 
  else if(kind=="swap"){g.DrawLine(p,s*.15f,s*.35f,s*.78f,s*.35f);g.DrawLine(p,s*.65f,s*.22f,s*.80f,s*.35f);g.DrawLine(p,s*.80f,s*.35f,s*.65f,s*.48f);g.DrawLine(p,s*.85f,s*.68f,s*.22f,s*.68f);g.DrawLine(p,s*.35f,s*.55f,s*.20f,s*.68f);g.DrawLine(p,s*.20f,s*.68f,s*.35f,s*.81f);} 
  else if(kind=="user"){g.FillEllipse(br,s*.35f,s*.13f,s*.30f,s*.30f);g.FillEllipse(br,s*.20f,s*.48f,s*.60f,s*.40f);} 
  else if(kind=="key"){g.DrawEllipse(p,s*.10f,s*.22f,s*.35f,s*.35f);g.DrawLine(p,s*.40f,s*.48f,s*.85f,s*.82f);g.DrawLine(p,s*.68f,s*.68f,s*.76f,s*.58f);} 
  else if(kind=="globe"){g.DrawEllipse(p,s*.10f,s*.10f,s*.80f,s*.80f);g.DrawEllipse(p,s*.32f,s*.10f,s*.36f,s*.80f);g.DrawLine(p,s*.12f,s*.5f,s*.88f,s*.5f);} 
  else if(kind=="moon"){g.FillEllipse(br,s*.18f,s*.12f,s*.68f,s*.72f);using var bg=new SolidBrush(Color.FromArgb(10,25,58));g.FillEllipse(bg,s*.38f,s*.04f,s*.62f,s*.66f);} 
  else if(kind=="shield"){var pts=new[]{new PointF(s*.5f,s*.08f),new PointF(s*.82f,s*.20f),new PointF(s*.76f,s*.62f),new PointF(s*.5f,s*.88f),new PointF(s*.24f,s*.62f),new PointF(s*.18f,s*.20f)};g.FillPolygon(br,pts);} 
  else if(kind=="refresh"||kind=="restore"){g.DrawArc(p,s*.15f,s*.15f,s*.70f,s*.70f,35,285);g.DrawLine(p,s*.76f,s*.16f,s*.84f,s*.36f);g.DrawLine(p,s*.84f,s*.36f,s*.64f,s*.34f);} 
  else {g.DrawRectangle(p,s*.20f,s*.20f,s*.60f,s*.60f);g.DrawLine(p,s*.08f,s*.35f,s*.20f,s*.35f);g.DrawLine(p,s*.08f,s*.65f,s*.20f,s*.65f);g.DrawLine(p,s*.80f,s*.35f,s*.92f,s*.35f);g.DrawLine(p,s*.80f,s*.65f,s*.92f,s*.65f);} return bmp;}
 void ManageField(GroupBox g,string label,int x,int y,string hint,Action<string> action,bool secret=false,string icon="user"){g.Controls.Add(IconBox(icon,x,y+2));var l=new Label{Text=label,Left=x+38,Top=y+6,Width=96,Height=26,ForeColor=Color.White,Font=new Font("Segoe UI",8.8f)};g.Controls.Add(l);var t=new TextBox{Left=x+134,Top=y,Width=142,Height=30,UseSystemPasswordChar=secret,PlaceholderText=hint,Font=new Font("Segoe UI",8.8f)};g.Controls.Add(t);var b=GB(g,"OK",x+282,y,54,32);b.Font=new Font("Segoe UI",8.6f);b.Click+=(_,_)=>action(t.Text);}
 void ManagePasswordField(GroupBox g,string label,int x,int y,string hint,string icon="key"){g.Controls.Add(IconBox(icon,x,y+2));var l=new Label{Text=label,Left=x+38,Top=y+6,Width=96,Height=26,ForeColor=Color.White,Font=new Font("Segoe UI",8.8f)};g.Controls.Add(l);var t=new TextBox{Left=x+134,Top=y,Width=142,Height=30,UseSystemPasswordChar=false,PlaceholderText=hint,Font=new Font("Segoe UI",8.8f)};g.Controls.Add(t);var b=GB(g,"OK",x+282,y,54,32);b.Font=new Font("Segoe UI",8.6f);b.Click+=(_,_)=>{if(ChangePassword(t.Text))t.Clear();};}
 void WireQuick(Button b,string n){b.Click+=(_,_)=>{switch(n){case "Tối ưu RAM":CleanTemp(false);MessageBox.Show("Đã dọn TEMP an toàn. Windows sẽ tự quản lý RAM.");break;case "Tối ưu CPU":Run("powercfg","/setactive SCHEME_MIN");break;case "Khởi động lại":if(Confirm("Khởi động lại VPS sau 5 giây?"))Run("shutdown","/r /t 5");break;case "Task Manager":Run("taskmgr.exe","");break;case "Xóa TEMP":CleanTemp(true);break;}};}
 void LoadToggleStates(){loadingChecks=true;try{SetCheck("UAC",RegDword(Registry.LocalMachine,@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System","EnableLUA",1)==1);SetCheck("Windows Update",ServiceStartEnabled("wuauserv"));SetCheck("Taskbar nhỏ",RegDword(Registry.CurrentUser,@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced","TaskbarSi",1)==0);SetCheck("Firewall",FirewallOn());SetCheck("Cho phép Sleep",true);SetCheck("System Restore",false);SetCheck("Tối ưu RDP",RegDword(Registry.LocalMachine,@"SYSTEM\CurrentControlSet\Control\Terminal Server","fDenyTSConnections",1)==0);SetCheck("Hiện icon Tray",false);}finally{loadingChecks=false;}}
 void SetCheck(string name,bool value){CheckBox? found=null;void Walk(Control root){foreach(Control c in root.Controls){if(c is CheckBox cb && cb.Name==name){found=cb;return;}Walk(c);if(found!=null)return;}}Walk(this);if(found!=null){found.Checked=value;UpdateToggleColor(found);}}
 void UpdateToggleColor(CheckBox c){c.ForeColor=c.Checked?Color.Orange:Color.White;c.Invalidate();}
 static int RegDword(RegistryKey root,string path,string name,int fallback){try{using var k=root.OpenSubKey(path);return Convert.ToInt32(k?.GetValue(name,fallback));}catch{return fallback;}}
 static bool ServiceStartEnabled(string name){try{using var k=Registry.LocalMachine.OpenSubKey($@"SYSTEM\CurrentControlSet\Services\{name}");return Convert.ToInt32(k?.GetValue("Start",4))!=4;}catch{return false;}}
 bool FirewallOn(){try{using var k=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile");return Convert.ToInt32(k?.GetValue("EnableFirewall",1))==1;}catch{return true;}}
 void ToggleChanged(object? sender,EventArgs e){if(loadingChecks||sender is not CheckBox c)return;bool on=c.Checked;switch(c.Name){case "UAC":RunWait("reg.exe",$@"add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d {(on?1:0)} /f");break;case "Windows Update":RunWait("sc.exe",on?"config wuauserv start= demand":"config wuauserv start= disabled");if(on)RunWait("sc.exe","start wuauserv");else RunWait("sc.exe","stop wuauserv");break;case "Hiện icon Tray":Run("explorer.exe","ms-settings:taskbar");MessageBox.Show("Windows quản lý từng biểu tượng Tray theo phiên bản. Hãy chọn biểu tượng cần hiện trong trang Taskbar vừa mở.","VPS");break;case "Taskbar nhỏ":using(var k=Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"))k.SetValue("TaskbarSi",on?0:1,RegistryValueKind.DWord);break;case "Firewall":RunWait("netsh",$"advfirewall set allprofiles state {(on?"on":"off")}");break;case "Cho phép Sleep":RunWait("powercfg",on?"-change -standby-timeout-ac 30":"-change -standby-timeout-ac 0");break;case "System Restore":RunWait("powershell",on?"-NoProfile -Command \"Enable-ComputerRestore -Drive 'C:\\\\'\"":"-NoProfile -Command \"Disable-ComputerRestore -Drive 'C:\\\\'\"");break;case "Tối ưu RDP":if(on)OptimizeRdp();else MessageBox.Show("Bỏ tick Tối ưu RDP không tự tắt Remote Desktop để tránh làm mất kết nối VPS.","VPS");break;}SetLog($"Đã {(on?"bật":"tắt")}: {c.Text}");status.Text="Sẵn sàng.";}
 void SyncTime(){RunWait("sc.exe","config w32time start= auto");RunWait("sc.exe","start w32time");RunWait("w32tm.exe","/resync /force");status.Text="Đã đồng bộ thời gian.";}
 async Task LoadApps(){try{var cfg=await http.GetFromJsonAsync<AppConfig>(AppsUrl);online=cfg?.apps??[];FixPrivateApps();appList.Items.Clear();var items=new List<string>();items.AddRange(online.Select(a=>$"{a.name} (v{a.version})"));items.AddRange(new[]{"Google Chrome","Visual C++ Redistributable x86","Proton VPN","UniKey","Notepad++","UltraViewer","WinRAR",".NET Framework 3.5","Microsoft Edge WebView2 Runtime",".NET 8 Desktop Runtime x64",".NET Desktop Runtime 6.0.13 x64"});foreach(var item in items.OrderBy(x=>x.TrimStart('.'),StringComparer.CurrentCultureIgnoreCase))appList.Items.Add(item);foreach(var item in webApps.Keys)appList.Items.Add(item);DetectInstalledApps();status.Text="Sẵn sàng.";}catch(Exception ex){status.Text="Không tải được apps.json: "+ex.Message;SetLog("Lỗi đọc danh sách phần mềm: "+ex.Message);}}
 void FixPrivateApps(){
  // Các gói riêng V1.1: URL cố định làm fallback nếu apps.json chưa cập nhật.
  // PS3838 Manager cũ được thay bằng Sports Manager.
  online.RemoveAll(a=>a.name.Equals("PS3838 Manager",StringComparison.OrdinalIgnoreCase));
  UpsertPrivate("Winner AutoLogin","4.0","https://github.com/phammachduc-blip/vps-/releases/download/V1.1/WinnerAutoLogin.zip","zip",null);
  UpsertPrivate("Proxy Sport","1.11.0","https://github.com/phammachduc-blip/vps-/releases/download/V1.1/Proxy_Sport.zip","zip","168168");
  UpsertPrivate("Sports Manager","1.1","https://github.com/phammachduc-blip/vps-/releases/download/V1.1/SPORTS_MANAGER_FINAL_LOGIN_ALIGNED.zip","zip",null);
  UpsertPrivate("Proxy Xoay","1.1","https://github.com/phammachduc-blip/vps-/releases/download/V1.1/ProxyXoay.zip","zip",null);
 }
 void UpsertPrivate(string name,string version,string url,string type,string? password){var i=online.FindIndex(a=>a.name.Equals(name,StringComparison.OrdinalIgnoreCase));var v=new AppItem(name,version,url,type,password);if(i>=0)online[i]=v;else online.Add(v);}
 async Task InstallSelected(){
  var selected=appList.CheckedItems.Cast<object>().Select(x=>x.ToString()!).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
  if(selected.Count==0){MessageBox.Show("Hãy tick phần mềm cần tải/cài.");return;}
  int ok=0,fail=0,skip=0;
  foreach(var text in selected){
   if(IsInstalled(text)){SetLog(text+" đã có - bỏ qua.");skip++;continue;}
   bool success;
   if(webApps.ContainsKey(text))success=InstallWebApp(text);
   else {var a=online.FirstOrDefault(x=>text.StartsWith(x.name+" (",StringComparison.OrdinalIgnoreCase));success=a!=null?await InstallOwn(a):await InstallSystemTracked(text);}
   if(success)ok++;else fail++;
  }
  DetectInstalledApps();status.Text="Sẵn sàng.";
  MessageBox.Show($"Hoàn tất. Thành công: {ok} | Đã có: {skip} | Lỗi: {fail}","VPS");
 }
 async Task<string> Download(string url,string name,string? forcedExt=null){
  status.Text="Đang tải "+name+"...";SetLog("Đang tải "+name+"...");
  using var req=new HttpRequestMessage(HttpMethod.Get,url);
  using var r=await http.SendAsync(req,HttpCompletionOption.ResponseHeadersRead);r.EnsureSuccessStatusCode();
  var finalUrl=r.RequestMessage?.RequestUri??new Uri(url);
  var ext=forcedExt;
  if(string.IsNullOrWhiteSpace(ext)){
   var cdName=r.Content.Headers.ContentDisposition?.FileNameStar??r.Content.Headers.ContentDisposition?.FileName;
   if(!string.IsNullOrWhiteSpace(cdName))ext=Path.GetExtension(cdName.Trim('"'));
   if(string.IsNullOrWhiteSpace(ext))ext=Path.GetExtension(finalUrl.AbsolutePath);
   if(string.IsNullOrWhiteSpace(ext))ext=Path.GetExtension(new Uri(url).AbsolutePath);
   if(string.IsNullOrWhiteSpace(ext))ext=".bin";
  }
  if(!ext.StartsWith('.'))ext="."+ext;
  var dl=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads","VPS-Tool");Directory.CreateDirectory(dl);var f=Path.Combine(dl,Safe(name)+"_"+Guid.NewGuid().ToString("N")[..6]+ext);
  await using var src=await r.Content.ReadAsStreamAsync();await using var dst=File.Create(f);await src.CopyToAsync(dst);
  var len=new FileInfo(f).Length;if(len<32)throw new InvalidDataException("File tải về rỗng hoặc không hợp lệ.");
  SetLog($"Đã tải {name}: {len/1024.0/1024.0:F1} MB. Đang xử lý...");return f;
 }
 async Task<string> DownloadOwn(AppItem a){
  var url=a.url;
  status.Text="Đang tải "+a.name+"...";SetLog("Đang tải "+a.name+" từ V1.1...");
  using var req=new HttpRequestMessage(HttpMethod.Get,url);
  using var r=await http.SendAsync(req,HttpCompletionOption.ResponseHeadersRead);r.EnsureSuccessStatusCode();
  var dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads","VPS-Tool");Directory.CreateDirectory(dir);
  var fileName=Path.GetFileName(new Uri(url).AbsolutePath);if(string.IsNullOrWhiteSpace(fileName))fileName=Safe(a.name)+".zip";
  var f=Path.Combine(dir,fileName);await using var src=await r.Content.ReadAsStreamAsync();await using var dst=File.Create(f);await src.CopyToAsync(dst);
  var len=new FileInfo(f).Length;if(len<32)throw new InvalidDataException("File tải về rỗng hoặc không hợp lệ.");
  SetLog($"Đã tải {a.name}: {len/1024.0/1024.0:F1} MB -> Downloads\\VPS-Tool");return f;
 }
 async Task<bool> InstallOwn(AppItem a){
  string? f=null;
  try{
   f=await DownloadOwn(a);
   if(a.type.Equals("zip",StringComparison.OrdinalIgnoreCase)){
    using(var z=File.OpenRead(f)){if(z.ReadByte()!=0x50||z.ReadByte()!=0x4B)throw new InvalidDataException("GitHub không trả về file ZIP hợp lệ.");}
    var root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads","VPS-Tool",Safe(a.name));
    if(Directory.Exists(root))Directory.Delete(root,true);Directory.CreateDirectory(root);
    SetLog("Đang giải nén "+a.name+"...");
    if(a.name.Equals("Proxy Sport",StringComparison.OrdinalIgnoreCase)){
     var pass=PromptZipPassword("Proxy Sport V1.1");
     if(pass==null)throw new OperationCanceledException("Đã hủy nhập mật khẩu giải nén.");
     try{ExtractPasswordZip(f,root,pass);}catch(Exception ex){throw new InvalidDataException("Không giải nén được Proxy Sport. Kiểm tra lại mật khẩu ZIP. Chi tiết: "+ex.Message);}
    }else if(string.IsNullOrEmpty(a.password))System.IO.Compression.ZipFile.ExtractToDirectory(f,root,true);else ExtractPasswordZip(f,root,a.password);
    if(!Directory.EnumerateFiles(root,"*",SearchOption.AllDirectories).Any())throw new InvalidDataException("ZIP giải nén xong nhưng không có file.");
    if(a.name.Equals("Proxy Sport",StringComparison.OrdinalIgnoreCase)){
     var manifest=Directory.EnumerateFiles(root,"manifest.json",SearchOption.AllDirectories).FirstOrDefault();
     if(manifest==null)throw new FileNotFoundException("Proxy Sport đã giải nén nhưng không tìm thấy manifest.json.");
     File.WriteAllText(Path.Combine(root,".vps-installed"),DateTime.Now.ToString("O"));
     SetLog("Proxy Sport: giải nén thành công. Đang mở trang Chrome Extensions...");
     ShowChromeExtensionsLink();
     var opened=await OpenChromeExtensions();
     if(opened)SetLog("Proxy Sport: đã giải nén. Nếu cần mở lại, bấm 'Mở trang Chrome Extensions' bên dưới.");
     else SetLog("Proxy Sport đã giải nén. Bấm 'Mở trang Chrome Extensions' bên dưới để mở trang Extensions.");
     MessageBox.Show("Proxy Sport đã giải nén thành công.\n\nNếu Chrome chưa ở trang Extensions, bấm link 'Mở trang Chrome Extensions' ngay dưới dòng Log của VPS Tool.","VPS");
     return true;
    }
    var exe=a.name.Equals("Proxy Xoay",StringComparison.OrdinalIgnoreCase)
     ? Directory.EnumerateFiles(root,"ProxyXoay.exe",SearchOption.AllDirectories).FirstOrDefault() ?? Directory.EnumerateFiles(root,"Xoay.exe",SearchOption.AllDirectories).FirstOrDefault()
     : FindMainExe(root);
    if(exe==null && IsBuildFromSourceApp(a.name)){
     SetLog($"{a.name}: chưa có EXE - đang chuẩn bị .NET 8 SDK...");
     if(!await EnsureDotNet8Sdk())throw new InvalidOperationException("Không cài/không tìm thấy .NET 8 SDK.");
     exe=await PublishDotNetProject(root,a.name);
    }
    if(exe==null)throw new InvalidDataException("Đã giải nén nhưng không tìm thấy file .exe hoặc project .NET 8 để build.");
    var shortcut=CreateDesktopShortcut(exe,a.name);
    if(!File.Exists(shortcut))throw new IOException("Đã giải nén nhưng tạo shortcut Desktop thất bại.");
    File.WriteAllText(Path.Combine(root,".vps-installed"),DateTime.Now.ToString("O"));
    SetLog($"Đã giải nén + tạo shortcut {a.name} ngoài Desktop.");return true;
   }
   var dest=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Path.GetFileName(new Uri(a.url).AbsolutePath));File.Copy(f,dest,true);SetLog("Đã tải "+a.name+" thành công.");return true;
  }catch(Exception ex){SetLog("Lỗi "+a.name+": "+ex.Message);MessageBox.Show($"Lỗi {a.name}: {ex.Message}","VPS");return false;}
 }
 async Task<bool> InstallSystemTracked(string n){try{await InstallSystem(n);return IsInstalled(n);}catch(Exception ex){SetLog("Lỗi "+n+": "+ex.Message);return false;}}
 async Task InstallSystem(string n){try{status.Text="Đang cài "+n+"...";if(n==".NET Framework 3.5"){RunWait("dism.exe","/online /enable-feature /featurename:NetFx3 /All /NoRestart");SetLog("Đã cài .NET Framework 3.5.");return;}string? url=n switch{"Google Chrome"=>"https://dl.google.com/chrome/install/latest/chrome_installer.exe","Visual C++ Redistributable x86"=>"https://aka.ms/vs/17/release/vc_redist.x86.exe","Microsoft Edge WebView2 Runtime"=>"https://go.microsoft.com/fwlink/p/?LinkId=2124703",".NET 8 Desktop Runtime x64"=>"https://aka.ms/dotnet/8.0/windowsdesktop-runtime-win-x64.exe",_=>null};if(n==".NET Desktop Runtime 6.0.13 x64")url=await FindDotNet613();if(n=="Notepad++")url=await FindLatestNotepadPlusPlusInstaller();if(url!=null){var f=await Download(url,n,".exe");var args=n=="Notepad++"?"/S":n.Contains("Chrome")?"/silent /install":n.Contains("WebView2")?"/silent /install":"/install /quiet /norestart";var code=RunWait(f,args);if(code!=0)throw new InvalidOperationException($"Bộ cài {n} trả về mã lỗi {code}.");SetLog("Đã cài "+n+".");return;}var id=n switch{"Proton VPN"=>"Proton.ProtonVPN","UniKey"=>"UniKey.UniKey","UltraViewer"=>"DucFabulous.UltraViewer","WinRAR"=>"RARLab.WinRAR",_=>null};if(id!=null){var c=RunWait("winget.exe",$"install --id {id} -e --accept-package-agreements --accept-source-agreements --silent");if(c!=0){SetLog("Cài "+n+" thất bại.");MessageBox.Show($"Không cài được {n} bằng winget. Kiểm tra winget/Internet.");}else SetLog("Đã cài "+n+".");}}catch(Exception ex){MessageBox.Show($"Lỗi {n}: {ex.Message}");}}
 async Task<string> FindDotNet613(){using var doc=JsonDocument.Parse(await http.GetStringAsync("https://dotnetcli.blob.core.windows.net/dotnet/release-metadata/6.0/releases.json"));foreach(var rel in doc.RootElement.GetProperty("releases").EnumerateArray()){if(rel.GetProperty("release-version").GetString()!="6.0.13")continue;foreach(var f in rel.GetProperty("windowsdesktop").GetProperty("files").EnumerateArray())if(f.GetProperty("name").GetString()=="windowsdesktop-runtime-win-x64.exe")return f.GetProperty("url").GetString()!;}throw new Exception("Không tìm thấy .NET Desktop Runtime 6.0.13 x64 trong metadata Microsoft.");}
 async Task<string> FindLatestNotepadPlusPlusInstaller(){using var doc=JsonDocument.Parse(await http.GetStringAsync("https://api.github.com/repos/notepad-plus-plus/notepad-plus-plus/releases/latest"));foreach(var a in doc.RootElement.GetProperty("assets").EnumerateArray()){var file=a.GetProperty("name").GetString()??"";if(file.EndsWith("Installer.x64.exe",StringComparison.OrdinalIgnoreCase))return a.GetProperty("browser_download_url").GetString()!;}throw new Exception("Không tìm thấy bộ cài Notepad++ x64 mới nhất.");}
 void ExtractPasswordZip(string zip,string root,string pass){using var fs=File.OpenRead(zip);using var zf=new SharpZipFile(fs);zf.Password=pass;var basePath=Path.GetFullPath(root)+Path.DirectorySeparatorChar;foreach(SharpZipEntry e in zf){if(!e.IsFile)continue;var dest=Path.GetFullPath(Path.Combine(root,e.Name.Replace('/',Path.DirectorySeparatorChar)));if(!dest.StartsWith(basePath,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("ZIP có đường dẫn không an toàn.");Directory.CreateDirectory(Path.GetDirectoryName(dest)!);using var input=zf.GetInputStream(e);using var output=File.Create(dest);input.CopyTo(output);}}

 string? PromptZipPassword(string appName){
  using var f=new Form{Text="Mật khẩu giải nén",ClientSize=new Size(390,145),StartPosition=FormStartPosition.CenterParent,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,BackColor=Color.White,ForeColor=Color.Black};
  var l=new Label{Text="Nhập mật khẩu ZIP cho "+appName+":",Left=20,Top=20,Width=345,Height=25};
  var t=new TextBox{Left=20,Top=50,Width=345,Height=27,UseSystemPasswordChar=true};
  var ok=new Button{Text="Giải nén",Left=175,Top=92,Width=90,Height=32,DialogResult=DialogResult.OK};
  var cancel=new Button{Text="Hủy",Left=275,Top=92,Width=90,Height=32,DialogResult=DialogResult.Cancel};
  f.Controls.AddRange(new Control[]{l,t,ok,cancel});f.AcceptButton=ok;f.CancelButton=cancel;
  return f.ShowDialog(this)==DialogResult.OK?t.Text:null;
 }

 bool IsBuildFromSourceApp(string name)=>name.Equals("Winner AutoLogin",StringComparison.OrdinalIgnoreCase)||name.Equals("Sports Manager",StringComparison.OrdinalIgnoreCase);
 bool HasDotNet8Sdk(){
  try{var root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"dotnet\sdk");return Directory.Exists(root)&&Directory.EnumerateDirectories(root,"8.*").Any();}catch{return false;}
 }
 async Task<bool> EnsureDotNet8Sdk(){
  if(HasDotNet8Sdk())return true;
  status.Text="Đang tải .NET 8 SDK...";SetLog("Chưa có .NET 8 SDK - đang tải từ Microsoft...");
  var f=await Download("https://aka.ms/dotnet/8.0/dotnet-sdk-win-x64.exe",".NET 8 SDK x64",".exe");
  SetLog("Đang cài .NET 8 SDK x64...");
  var code=RunWait(f,"/install /quiet /norestart");
  if(code!=0 && code!=3010){SetLog($"Cài .NET 8 SDK lỗi, mã {code}.");return false;}
  var dotnet=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"dotnet\dotnet.exe");
  var ok=File.Exists(dotnet)&&HasDotNet8Sdk();SetLog(ok?"Đã cài .NET 8 SDK.":"Cài SDK xong nhưng chưa phát hiện dotnet SDK 8.");return ok;
 }
 async Task<string> PublishDotNetProject(string root,string appName){
  await Task.Yield();
  var projects=Directory.EnumerateFiles(root,"*.csproj",SearchOption.AllDirectories).Where(x=>!x.Contains($"{Path.DirectorySeparatorChar}obj{Path.DirectorySeparatorChar}")&&!x.Contains($"{Path.DirectorySeparatorChar}bin{Path.DirectorySeparatorChar}")).ToList();
  if(projects.Count==0)throw new FileNotFoundException("Không tìm thấy file .csproj trong gói V1.1.");
  var csproj=projects.OrderByDescending(x=>Path.GetFileNameWithoutExtension(x).Contains(appName.Split(' ')[0],StringComparison.OrdinalIgnoreCase)).ThenBy(x=>x.Length).First();
  var dotnet=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"dotnet\dotnet.exe");if(!File.Exists(dotnet))dotnet="dotnet.exe";
  var outDir=Path.Combine(root,"VPS-Publish");if(Directory.Exists(outDir))Directory.Delete(outDir,true);Directory.CreateDirectory(outDir);
  status.Text="Đang build "+appName+"...";SetLog($"Đang chạy .NET 8 publish: {Path.GetFileName(csproj)}...");
  var args=$"publish \"{csproj}\" -c Release -r win-x64 --self-contained true -o \"{outDir}\"";
  var logFile=Path.Combine(root,"vps-publish.log");
  var psi=new ProcessStartInfo(dotnet,args){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,WorkingDirectory=Path.GetDirectoryName(csproj)!};
  using var pr=Process.Start(psi)??throw new InvalidOperationException("Không chạy được dotnet publish.");var stdout=await pr.StandardOutput.ReadToEndAsync();var stderr=await pr.StandardError.ReadToEndAsync();await pr.WaitForExitAsync();File.WriteAllText(logFile,stdout+Environment.NewLine+stderr);
  if(pr.ExitCode!=0)throw new InvalidOperationException($"dotnet publish thất bại (mã {pr.ExitCode}). Xem log: {logFile}");
  var exe=FindMainExe(outDir);if(exe==null)throw new FileNotFoundException("Build hoàn tất nhưng không tìm thấy EXE trong VPS-Publish.");
  SetLog($"Build {appName} thành công - đang tạo shortcut Desktop...");return exe;
 }
 void SetupAppContextMenu(){
  var menu=new ContextMenuStrip();var uninstall=new ToolStripMenuItem("Gỡ cài đặt");var editLink=new ToolStripMenuItem("Thêm / đổi link");menu.Items.Add(uninstall);menu.Items.Add(editLink);
  menu.Opening+=(sender,e)=>{var text=appList.SelectedIndex>=0?appList.Items[appList.SelectedIndex]?.ToString()??"":"";bool isWeb=webApps.ContainsKey(text);uninstall.Enabled=isWeb?IsWebAppInstalled(text):(!string.IsNullOrWhiteSpace(text)&&installedItems.Contains(text));editLink.Visible=isWeb;editLink.Enabled=isWeb;};
  uninstall.Click+=async(_,_)=>{if(appList.SelectedIndex<0)return;var text=appList.Items[appList.SelectedIndex]?.ToString()??"";if(webApps.ContainsKey(text)){UninstallWebApp(text);DetectInstalledApps();}else await UninstallApp(text);};
  editLink.Click+=(_,_)=>{if(appList.SelectedIndex<0)return;var text=appList.Items[appList.SelectedIndex]?.ToString()??"";if(webApps.ContainsKey(text))EditWebAppLink(text);};
  appList.MouseDown+=(s,e)=>{if(e.Button!=MouseButtons.Right)return;var i=appList.IndexFromPoint(e.Location);if(i>=0)appList.SelectedIndex=i;};appList.ContextMenuStrip=menu;
 }
 void LoadWebAppLinks(){try{if(!File.Exists(WebAppConfigPath))return;var saved=JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(WebAppConfigPath));if(saved==null)return;foreach(var k in webApps.Keys.ToList())if(saved.TryGetValue(k,out var u)&&IsHttpUrl(u))webApps[k]=u;}catch{}}
 void SaveWebAppLinks(){try{Directory.CreateDirectory(Path.GetDirectoryName(WebAppConfigPath)!);File.WriteAllText(WebAppConfigPath,JsonSerializer.Serialize(webApps,new JsonSerializerOptions{WriteIndented=true}));}catch(Exception ex){MessageBox.Show("Không lưu được link: "+ex.Message,"VPS");}}
 static bool IsHttpUrl(string s)=>Uri.TryCreate(s,UriKind.Absolute,out var u)&&(u.Scheme==Uri.UriSchemeHttp||u.Scheme==Uri.UriSchemeHttps);
 const string ChromeWebAppPolicyKey=@"SOFTWARE\Policies\Google\Chrome\WebAppInstallForceList";
 string WebAppPolicyJson(string url)=>JsonSerializer.Serialize(new Dictionary<string,object>{{"url",url},{"default_launch_container","window"},{"create_desktop_shortcut",true}});
 bool PolicyEntryMatches(string json,string url){try{using var d=JsonDocument.Parse(json);return d.RootElement.TryGetProperty("url",out var u)&&string.Equals(u.GetString()?.TrimEnd('/'),url.TrimEnd('/'),StringComparison.OrdinalIgnoreCase);}catch{return false;}}
 bool IsWebAppInstalled(string name){if(!webApps.TryGetValue(name,out var url))return false;try{using var k=Registry.LocalMachine.OpenSubKey(ChromeWebAppPolicyKey);if(k==null)return false;return k.GetValueNames().Any(v=>k.GetValue(v) is string j&&PolicyEntryMatches(j,url));}catch{return false;}}
 void AddChromeWebAppPolicy(string url){using var k=Registry.LocalMachine.CreateSubKey(ChromeWebAppPolicyKey,true)??throw new InvalidOperationException("Không mở được Chrome policy.");foreach(var v in k.GetValueNames())if(k.GetValue(v) is string j&&PolicyEntryMatches(j,url))return;int n=1;var used=new HashSet<string>(k.GetValueNames(),StringComparer.OrdinalIgnoreCase);while(used.Contains(n.ToString()))n++;k.SetValue(n.ToString(),WebAppPolicyJson(url),RegistryValueKind.String);}
 void RemoveChromeWebAppPolicy(string url){using var k=Registry.LocalMachine.OpenSubKey(ChromeWebAppPolicyKey,true);if(k==null)return;foreach(var v in k.GetValueNames().ToArray())if(k.GetValue(v) is string j&&PolicyEntryMatches(j,url))k.DeleteValue(v,false);}
 void NudgeChromePolicy(){try{var chrome=FindChromeExe();if(chrome!=null)Process.Start(new ProcessStartInfo(chrome,"--new-window chrome://policy"){UseShellExecute=true});}catch{}}
 bool InstallWebApp(string name){
  try{
   if(!webApps.TryGetValue(name,out var url)||!IsHttpUrl(url)){MessageBox.Show("Link của "+name+" không hợp lệ. Chuột phải → Thêm / đổi link.","VPS");return false;}
   if(FindChromeExe()==null){MessageBox.Show("Chưa tìm thấy Google Chrome. Hãy cài Chrome trước.","VPS");return false;}
   AddChromeWebAppPolicy(url);NudgeChromePolicy();
   SetLog("Đã yêu cầu Chrome cài "+name+" như Web App thật → "+url);
   MessageBox.Show(name+" đã được thêm vào cơ chế Web App của chính Chrome.\n\nChrome sẽ tự cài app, lấy icon của website và tạo shortcut Desktop. Quá trình có thể mất vài giây.\n\nĐây không còn là shortcut chrome.exe --app nữa. Sau khi app xuất hiện, bạn có thể mở app và ghim icon của app lên Taskbar.","VPS");
   return true;
  }catch(Exception ex){SetLog("Lỗi cài "+name+": "+ex.Message);MessageBox.Show("Không cài được "+name+": "+ex.Message,"VPS");return false;}
 }
 void UninstallWebApp(string name){try{if(!webApps.TryGetValue(name,out var url))return;RemoveChromeWebAppPolicy(url);NudgeChromePolicy();SetLog("Đã gỡ chính sách Web App "+name+". Chrome sẽ tự gỡ app đã cài.");MessageBox.Show("Đã yêu cầu Chrome gỡ "+name+". Nếu Chrome đang mở, việc gỡ có thể cần vài giây để đồng bộ.","VPS");}catch(Exception ex){MessageBox.Show("Không gỡ được "+name+": "+ex.Message,"VPS");}}
 void EditWebAppLink(string name){var old=webApps[name];var input=Microsoft.VisualBasic.Interaction.InputBox("Nhập link cho "+name+":", "Thêm / đổi link",old).Trim();if(string.IsNullOrWhiteSpace(input))return;if(!IsHttpUrl(input)){MessageBox.Show("Link phải bắt đầu bằng http:// hoặc https://","VPS");return;}bool wasInstalled=IsWebAppInstalled(name);if(wasInstalled)RemoveChromeWebAppPolicy(old);webApps[name]=input;SaveWebAppLinks();if(wasInstalled){InstallWebApp(name);MessageBox.Show("Đã lưu link mới. Chrome sẽ thay Web App cũ bằng link mới của "+name+".","VPS");}else MessageBox.Show("Đã lưu link mới cho "+name+".","VPS");}
 async Task UninstallApp(string name){
  if(!installedItems.Contains(name)){MessageBox.Show("Phần mềm này chưa được phát hiện trên máy.","VPS");return;}
  if(!Confirm($"Gỡ cài đặt {name}?"))return;
  try{
   var own=online.FirstOrDefault(a=>name.StartsWith(a.name,StringComparison.OrdinalIgnoreCase));
   if(own!=null){
    var root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads","VPS-Tool",Safe(own.name));
    if(own.name.Equals("Winner AutoLogin",StringComparison.OrdinalIgnoreCase)){UninstallWinnerAutoLogin(root);DeleteDownloadedArchives(own.name,own.url);DetectInstalledApps();return;}
    foreach(var d in new[]{Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory)}){var l=Path.Combine(d,Safe(own.name)+".lnk");if(File.Exists(l))File.Delete(l);}
    DeleteDirectoryRobust(root);
    DeleteDownloadedArchives(own.name,own.url);
    if(own.name.Equals("Proxy Sport",StringComparison.OrdinalIgnoreCase))MessageBox.Show("Đã xóa thư mục Proxy Sport và tệp nén đã tải. Nếu tiện ích vẫn còn trong Chrome, mở chrome://extensions và bấm Remove để gỡ khỏi Chrome.","VPS");
    SetLog("Đã gỡ "+own.name+" và xóa tệp nén đã tải.");DetectInstalledApps();return;
   }
   if(name.Equals("Notepad++",StringComparison.OrdinalIgnoreCase)){UninstallNotepadPlusPlus();}
   else {
    var id=name switch{"Google Chrome"=>"Google.Chrome","Proton VPN"=>"Proton.ProtonVPN","UniKey"=>"UniKey.UniKey","UltraViewer"=>"DucFabulous.UltraViewer","WinRAR"=>"RARLab.WinRAR","Visual C++ Redistributable x86"=>"Microsoft.VCRedist.2015+.x86",_=>null};
    if(id!=null){var code=RunWait("winget.exe",$"uninstall --id {id} -e --silent --accept-source-agreements");if(code!=0)throw new InvalidOperationException("winget uninstall lỗi, mã "+code);}
    else {Run("appwiz.cpl","");MessageBox.Show("Đã mở Programs and Features. Chọn đúng thành phần .NET/Windows cần gỡ để tránh ảnh hưởng phần mềm khác.","VPS");return;}
   }
   await Task.Delay(500);DeleteDownloadedArchives(name,null);SetLog("Đã gỡ "+name+" và đã dọn tệp nén liên quan.");DetectInstalledApps();
  }catch(Exception ex){SetLog("Lỗi gỡ "+name+": "+ex.Message);MessageBox.Show("Không gỡ được "+name+": "+ex.Message,"VPS");}
 }
 void UninstallNotepadPlusPlus(){
  string? uninstall=null;
  foreach(var view in new[]{RegistryView.Registry64,RegistryView.Registry32})try{
   using var baseKey=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,view);
   using var root=baseKey.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
   if(root==null)continue;
   foreach(var subName in root.GetSubKeyNames()){using var sub=root.OpenSubKey(subName);var display=sub?.GetValue("DisplayName")?.ToString()??"";if(display.StartsWith("Notepad++",StringComparison.OrdinalIgnoreCase)){uninstall=sub?.GetValue("UninstallString")?.ToString();if(!string.IsNullOrWhiteSpace(uninstall))break;}}
   if(!string.IsNullOrWhiteSpace(uninstall))break;
  }catch{}
  if(string.IsNullOrWhiteSpace(uninstall)){var direct=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"Notepad++\uninstall.exe");if(File.Exists(direct))uninstall="\""+direct+"\"";}
  if(string.IsNullOrWhiteSpace(uninstall))throw new InvalidOperationException("Không tìm thấy trình gỡ cài đặt Notepad++.");
  var cmd=uninstall.Trim();string exe,args;
  if(cmd.StartsWith("\"")){var end=cmd.IndexOf('"',1);if(end<1)throw new InvalidOperationException("Lệnh gỡ Notepad++ không hợp lệ.");exe=cmd.Substring(1,end-1);args=cmd[(end+1)..].Trim();}else{var sp=cmd.IndexOf(' ');if(sp>0){exe=cmd[..sp];args=cmd[(sp+1)..];}else{exe=cmd;args="";}}
  if(Path.GetFileName(exe).Equals("uninstall.exe",StringComparison.OrdinalIgnoreCase)&&!args.Contains("/S",StringComparison.OrdinalIgnoreCase))args=(args+" /S").Trim();
  var code=RunWait(exe,args);if(code!=0)throw new InvalidOperationException("Trình gỡ Notepad++ trả về mã lỗi "+code);
 }
 void RenameUser(string v){if(string.IsNullOrWhiteSpace(v))return;var q=v.Replace("'","''");Run("powershell",$"-NoProfile -Command \"Rename-LocalUser -Name $env:USERNAME -NewName '{q}'\"");}
 bool ChangePassword(string v){
  if(string.IsNullOrEmpty(v))return false;
  try{
   var psi=new ProcessStartInfo("powershell.exe","-NoProfile -NonInteractive -Command \"$ErrorActionPreference='Stop'; $p=ConvertTo-SecureString $env:VPS_NEW_PASS -AsPlainText -Force; Set-LocalUser -Name $env:USERNAME -Password $p\""){UseShellExecute=false,CreateNoWindow=true,RedirectStandardError=true};
   psi.Environment["VPS_NEW_PASS"]=v;
   using var proc=Process.Start(psi); if(proc==null)throw new InvalidOperationException("Không khởi động được PowerShell.");
   var err=proc.StandardError.ReadToEnd(); proc.WaitForExit();
   if(proc.ExitCode!=0)throw new InvalidOperationException(string.IsNullOrWhiteSpace(err)?"Windows trả về mã lỗi "+proc.ExitCode:err.Trim());
   MessageBox.Show("Đổi mật khẩu thành công.","VPS"); return true;
  }catch(Exception ex){MessageBox.Show("Không đổi được mật khẩu: "+ex.Message,"VPS");return false;}
 }
 void ChangeRdp(string s){if(!ValidPort(s,out var p)){MessageBox.Show("Port phải từ 1 đến 65535.");return;}var old=GetRdp();if(old==p){MessageBox.Show("RDP đang dùng port này.");return;}if(!Confirm($"Đổi RDP {old} → {p}?\n\nTool sẽ mở port mới trước và chặn port cũ. Sau đó cần restart Windows. Hãy chắc chắn nhà cung cấp VPS không chặn port {p}."))return;RunWait("netsh",$"advfirewall firewall add rule name=\"VPS Tool RDP {p}\" dir=in action=allow protocol=TCP localport={p}");using(var k=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp",true))k?.SetValue("PortNumber",p,RegistryValueKind.DWord);RunWait("netsh",$"advfirewall firewall delete rule name=\"VPS Tool RDP {old}\"");RunWait("netsh",$"advfirewall firewall delete rule name=\"VPS Tool Close Old RDP {old}\"");RunWait("netsh",$"advfirewall firewall add rule name=\"VPS Tool Close Old RDP {old}\" dir=in action=block protocol=TCP localport={old}");MessageBox.Show($"Đã cấu hình {old} → {p}.\nRestart Windows rồi kết nối: IP-VPS:{p}");RefreshStatus();}
 static bool ValidPort(string s,out int p)=>int.TryParse(s,out p)&&p is>=1 and<=65535; int GetRdp(){using var k=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp");return Convert.ToInt32(k?.GetValue("PortNumber",3389));}
 void ExtendC(){if(!Confirm("Mở rộng C: sẽ dùng vùng Unallocated liền kề ngay sau C:. Nếu không có vùng phù hợp, lệnh sẽ không thực hiện. Tiếp tục?"))return;var f=Path.Combine(Path.GetTempPath(),"vps_extend.txt");File.WriteAllText(f,"select volume C\r\nextend\r\nexit\r\n");RunWait("diskpart.exe",$"/s \"{f}\"");MessageBox.Show("Đã chạy lệnh Extend. Mở Disk Management để kiểm tra kết quả.");}
 void CreateD(){if(DriveInfo.GetDrives().Any(x=>x.Name.Equals("D:\\\\",StringComparison.OrdinalIgnoreCase))){MessageBox.Show("Ổ D: đã tồn tại.");return;}var input=Microsoft.VisualBasic.Interaction.InputBox("Nhập dung lượng ổ D muốn tạo (GB). Tool sẽ shrink C: đúng dung lượng này.","Tạo ổ D","20");if(!int.TryParse(input,out var gb)||gb<1||gb>2048){MessageBox.Show("Dung lượng không hợp lệ.");return;}if(!Confirm($"Tạo D: {gb} GB bằng cách thu nhỏ C:?\n\nHãy sao lưu dữ liệu quan trọng trước khi thay đổi phân vùng."))return;var mb=gb*1024;var f=Path.Combine(Path.GetTempPath(),"vps_created.txt");File.WriteAllText(f,$"select volume C\r\nshrink desired={mb}\r\ncreate partition primary\r\nformat fs=ntfs quick label=Data\r\nassign letter=D\r\nexit\r\n");RunWait("diskpart.exe",$"/s \"{f}\"");MessageBox.Show("Đã chạy thao tác tạo D:. Mở Disk Management để kiểm tra.");}
 void OptimizeRdp(){RunWait("reg.exe",@"add HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server /v fDenyTSConnections /t REG_DWORD /d 0 /f");RunWait("netsh","advfirewall firewall set rule group=\"remote desktop\" new enable=Yes");MessageBox.Show("Đã bật RDP và rule Remote Desktop. Không tắt dịch vụ hệ thống quan trọng.");}
 void CleanTemp(bool msg){int count=0;foreach(var dir in new[]{Path.GetTempPath(),@"C:\Windows\Temp"})try{foreach(var f in Directory.EnumerateFiles(dir,"*",SearchOption.AllDirectories))try{File.Delete(f);count++;}catch{}}catch{}if(msg)MessageBox.Show($"Đã xóa {count} file TEMP có thể xóa.");}
 string? FindMainExe(string root){return Directory.EnumerateFiles(root,"*.exe",SearchOption.AllDirectories).Where(f=>!Path.GetFileName(f).Contains("unins",StringComparison.OrdinalIgnoreCase)&&!Path.GetFileName(f).Contains("update",StringComparison.OrdinalIgnoreCase)).OrderByDescending(f=>new FileInfo(f).Length).FirstOrDefault() ?? Directory.EnumerateFiles(root,"*.exe",SearchOption.AllDirectories).OrderByDescending(f=>new FileInfo(f).Length).FirstOrDefault();}
 string CreateDesktopShortcut(string exe,string name){
  var desktop=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);Directory.CreateDirectory(desktop);
  var lnk=Path.Combine(desktop,Safe(name)+".lnk");
  var ps="$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut($env:VPS_LNK);$s.TargetPath=$env:VPS_EXE;$s.WorkingDirectory=[IO.Path]::GetDirectoryName($env:VPS_EXE);$s.IconLocation=$env:VPS_EXE+',0';$s.Save()";
  var pi=new ProcessStartInfo("powershell.exe","-NoProfile -ExecutionPolicy Bypass -Command \""+ps+"\""){UseShellExecute=false,CreateNoWindow=true};pi.Environment["VPS_LNK"]=lnk;pi.Environment["VPS_EXE"]=exe;using var pr=Process.Start(pi);pr?.WaitForExit();if(pr==null||pr.ExitCode!=0)throw new IOException("PowerShell không tạo được shortcut.");return lnk;
 }
 void ShowChromeExtensionsLink(){try{var l=Controls.Find("ChromeExtensionsLink",true).FirstOrDefault() as LinkLabel;if(l!=null)l.Visible=true;}catch{}}
 async Task<bool> OpenChromeExtensions(){
  try{
   var chrome=FindChromeExe();if(chrome==null){MessageBox.Show("Chưa tìm thấy Google Chrome trên VPS.","VPS");return false;}
   var p=Process.Start(new ProcessStartInfo{FileName=chrome,UseShellExecute=true});
   await Task.Delay(1800);
   Process? target=p;
   if(target==null||target.HasExited||target.MainWindowHandle==IntPtr.Zero)target=Process.GetProcessesByName("chrome").Where(x=>x.MainWindowHandle!=IntPtr.Zero).OrderByDescending(x=>x.StartTime).FirstOrDefault();
   if(target==null||target.MainWindowHandle==IntPtr.Zero)return false;
   SetForegroundWindow(target.MainWindowHandle);await Task.Delay(250);
   SendKeys.SendWait("^l");await Task.Delay(100);
   SendKeys.SendWait("chrome://extensions/");SendKeys.SendWait("{ENTER}");
   return true;
  }catch(Exception ex){SetLog("Không tự mở được Chrome Extensions: "+ex.Message);return false;}
 }

 string ProxyConfigPath=>Path.Combine(AppContext.BaseDirectory,"proxy.txt");
 void EnsureProxyConfig(){try{if(!File.Exists(ProxyConfigPath))File.WriteAllText(ProxyConfigPath,"VN=162.128.157.171:14577\r\nUSA=198.44.167.42:15008\r\n");}catch(Exception ex){SetLog("Không tạo được proxy.txt: "+ex.Message);}}
 void CopyProxy(string key,string label){try{EnsureProxyConfig();var line=File.ReadLines(ProxyConfigPath).Select(x=>x.Trim()).FirstOrDefault(x=>x.StartsWith(key+"=",StringComparison.OrdinalIgnoreCase));var value=line==null?"":line[(line.IndexOf('=')+1)..].Trim();if(string.IsNullOrWhiteSpace(value)){MessageBox.Show("Không tìm thấy "+key+" trong proxy.txt.","VPS");return;}Clipboard.SetText(value);SetLog("Đã copy "+label+": "+value);}catch(Exception ex){MessageBox.Show("Không copy được proxy: "+ex.Message,"VPS");}}
 void DeleteDirectoryRobust(string path){
  if(!Directory.Exists(path))return;
  foreach(var f in Directory.EnumerateFiles(path,"*",SearchOption.AllDirectories))try{File.SetAttributes(f,FileAttributes.Normal);}catch{}
  foreach(var d in Directory.EnumerateDirectories(path,"*",SearchOption.AllDirectories).OrderByDescending(x=>x.Length))try{File.SetAttributes(d,FileAttributes.Normal);}catch{}
  try{File.SetAttributes(path,FileAttributes.Normal);}catch{}
  Directory.Delete(path,true);
 }
 void DeleteDownloadedArchives(string appName,string? sourceUrl){
  var baseDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads","VPS-Tool");if(!Directory.Exists(baseDir))return;
  var names=new HashSet<string>(StringComparer.OrdinalIgnoreCase){Safe(appName),appName.Replace(" ","")};
  if(!string.IsNullOrWhiteSpace(sourceUrl))try{var n=Path.GetFileNameWithoutExtension(new Uri(sourceUrl).AbsolutePath);if(!string.IsNullOrWhiteSpace(n))names.Add(n);}catch{}
  foreach(var f in Directory.EnumerateFiles(baseDir,"*",SearchOption.TopDirectoryOnly))try{
   var ext=Path.GetExtension(f);if(!new[]{".zip",".rar",".7z"}.Contains(ext,StringComparer.OrdinalIgnoreCase))continue;
   var stem=Path.GetFileNameWithoutExtension(f).Replace(" ","");
   if(names.Any(n=>stem.Contains(n.Replace(" ",""),StringComparison.OrdinalIgnoreCase))){File.SetAttributes(f,FileAttributes.Normal);File.Delete(f);}
  }catch{}
 }
 void UninstallWinnerAutoLogin(string root){
  var baseDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads","VPS-Tool");
  var roots=new HashSet<string>(StringComparer.OrdinalIgnoreCase){root,Path.Combine(baseDir,"WinnerAutoLogin"),Path.Combine(baseDir,"Winner AutoLogin")};
  try{if(Directory.Exists(baseDir))foreach(var d in Directory.EnumerateDirectories(baseDir)){var n=Path.GetFileName(d).Replace(" ","").Replace("-","").Replace("_","");if(n.Contains("WinnerAutoLogin",StringComparison.OrdinalIgnoreCase))roots.Add(d);}}catch{}

  // WinnerAutoLogin là app portable. Phải tắt tiến trình trước, nếu không EXE/config/log
  // đang bị khóa và Windows không thể xóa hết thư mục.
  var processErrors=new List<string>();
  foreach(var p in Process.GetProcesses())try{
   var pn=p.ProcessName.Replace(" ","").Replace("-","").Replace("_","");
   bool isWinner=pn.Equals("WinnerAutoLogin",StringComparison.OrdinalIgnoreCase);
   if(!isWinner)try{var exe=p.MainModule?.FileName;isWinner=!string.IsNullOrWhiteSpace(exe)&&roots.Any(r=>Path.GetFullPath(exe).StartsWith(Path.GetFullPath(r)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase));}catch{}
   if(!isWinner)continue;
   try{if(p.MainWindowHandle!=IntPtr.Zero)p.CloseMainWindow();}catch{}
   try{if(!p.WaitForExit(1500)){p.Kill(true);p.WaitForExit(5000);}}catch(Exception ex){processErrors.Add(p.ProcessName+": "+ex.Message);}
  }catch{}finally{p.Dispose();}

  var desktopDirs=new[]{Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory),Environment.GetFolderPath(Environment.SpecialFolder.StartMenu),Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu)};
  var shortcutErrors=new List<string>();
  foreach(var d in desktopDirs)try{if(!Directory.Exists(d))continue;foreach(var f in Directory.EnumerateFiles(d,"*.lnk",SearchOption.AllDirectories).Where(f=>{var n=Path.GetFileNameWithoutExtension(f).Replace(" ","");return n.Contains("WinnerAutoLogin",StringComparison.OrdinalIgnoreCase)||n.Contains("Winner",StringComparison.OrdinalIgnoreCase)&&n.Contains("Auto",StringComparison.OrdinalIgnoreCase);}))try{File.SetAttributes(f,FileAttributes.Normal);File.Delete(f);}catch(Exception ex){shortcutErrors.Add(f+": "+ex.Message);}}catch{}

  var errors=new List<string>();
  foreach(var d in roots){
   Exception? last=null;
   for(int attempt=0;attempt<3&&Directory.Exists(d);attempt++)try{DeleteDirectoryRobust(d);last=null;}catch(Exception ex){last=ex;Thread.Sleep(500);}
   if(Directory.Exists(d))errors.Add(d+": "+(last?.Message??"không xóa được thư mục"));
  }
  DeleteDownloadedArchives("Winner AutoLogin","https://github.com/phammachduc-blip/vps-/releases/download/V1.1/WinnerAutoLogin.zip");

  var remains=roots.Where(Directory.Exists).ToList();
  var running=new List<string>();
  foreach(var p in Process.GetProcesses())try{var pn=p.ProcessName.Replace(" ","").Replace("-","").Replace("_","");if(pn.Equals("WinnerAutoLogin",StringComparison.OrdinalIgnoreCase))running.Add(p.ProcessName+" (PID "+p.Id+")");}catch{}finally{p.Dispose();}
  var remainingShortcuts=new List<string>();
  foreach(var d in desktopDirs)try{if(Directory.Exists(d))remainingShortcuts.AddRange(Directory.EnumerateFiles(d,"*.lnk",SearchOption.AllDirectories).Where(f=>Path.GetFileNameWithoutExtension(f).Replace(" ","").Contains("WinnerAutoLogin",StringComparison.OrdinalIgnoreCase)));}catch{}

  if(remains.Count>0||running.Count>0||errors.Count>0||processErrors.Count>0||shortcutErrors.Count>0||remainingShortcuts.Count>0){
   var detail=string.Join("\n",processErrors.Select(x=>"Không tắt được: "+x).Concat(shortcutErrors.Select(x=>"Không xóa shortcut: "+x)).Concat(errors).Concat(remains.Select(x=>"Còn thư mục: "+x)).Concat(running.Select(x=>"Còn tiến trình: "+x)).Concat(remainingShortcuts.Select(x=>"Còn shortcut: "+x)));
   throw new IOException("Winner AutoLogin chưa được gỡ hoàn toàn.\n\n"+detail);
  }
  SetLog("Đã tắt Winner AutoLogin, xóa app portable, config/log, shortcut và tệp nén.");
  MessageBox.Show("Đã gỡ hoàn toàn Winner AutoLogin.\n\nĐã tắt tiến trình và xóa thư mục chương trình, winner_config.json, winner_debug.log, shortcut và tệp nén đã tải.","VPS");
 }

  void SetLog(string text){try{var l=Controls.Find("LastLog",true).FirstOrDefault() as Label;if(l!=null)l.Text="Log: "+text;}catch{}}
 void DrawAppItem(object? sender,DrawItemEventArgs e){
  if(e.Index<0)return;e.DrawBackground();var text=appList.Items[e.Index]?.ToString()??"";
  var state=appList.GetItemChecked(e.Index)?System.Windows.Forms.VisualStyles.CheckBoxState.CheckedNormal:System.Windows.Forms.VisualStyles.CheckBoxState.UncheckedNormal;
  var cb=new Point(e.Bounds.Left+2,e.Bounds.Top+2);System.Windows.Forms.CheckBoxRenderer.DrawCheckBox(e.Graphics,cb,state);
  var c=installedItems.Contains(text)?Color.Orange:Color.White;using var br=new SolidBrush(c);e.Graphics.DrawString(text,appList.Font,br,e.Bounds.Left+22,e.Bounds.Top+1);e.DrawFocusRectangle();
 }
 void DetectInstalledApps(){
  installedItems.Clear();loadingChecks=true;
  try{
   for(int i=0;i<appList.Items.Count;i++){
    var raw=appList.Items[i]?.ToString()??"";var text=raw;bool installed=IsInstalled(text);
    if(installed)installedItems.Add(text);
    appList.Items[i]=text;
    appList.SetItemChecked(i,false); // checkbox chỉ dùng để CHỌN cài
   }
  }finally{loadingChecks=false;appList.Invalidate();appList.Refresh();}
 }
 bool IsInstalled(string text){
  try{
   if(webApps.ContainsKey(text))return IsWebAppInstalled(text);
   var own=online.FirstOrDefault(a=>text.StartsWith(a.name+" (",StringComparison.OrdinalIgnoreCase));
   if(own!=null){
    if(own.type.Equals("file",StringComparison.OrdinalIgnoreCase))return File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Path.GetFileName(new Uri(own.url).AbsolutePath)));
    var ownRoot=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads","VPS-Tool",Safe(own.name));
    var desktop=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
    var commonDesktop=Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory);
    if(File.Exists(Path.Combine(desktop,Safe(own.name)+".lnk"))||File.Exists(Path.Combine(commonDesktop,Safe(own.name)+".lnk")))return true;
    return Directory.Exists(ownRoot) && (File.Exists(Path.Combine(ownRoot,".vps-installed")) || FindMainExe(ownRoot)!=null);
   }
   if(text=="Google Chrome")return File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"Google\Chrome\Application\chrome.exe"))||File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),@"Google\Chrome\Application\chrome.exe"));
   if(text=="WinRAR")return File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"WinRAR\WinRAR.exe"));
   if(text=="Notepad++")return File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"Notepad++\notepad++.exe"));
   if(text==".NET Framework 3.5")return RegDword(Registry.LocalMachine,@"SOFTWARE\Microsoft\NET Framework Setup\NDP\v3.5","Install",0)==1;
   if(text==".NET 8 Desktop Runtime x64")return Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"dotnet\shared\Microsoft.WindowsDesktop.App"))&&Directory.EnumerateDirectories(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"dotnet\shared\Microsoft.WindowsDesktop.App"),"8.*").Any();
   if(text==".NET Desktop Runtime 6.0.13 x64")return Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"dotnet\shared\Microsoft.WindowsDesktop.App\6.0.13"));
   if(text=="Microsoft Edge WebView2 Runtime")return HasUninstallDisplay("Microsoft Edge WebView2 Runtime")||HasUninstallDisplay("WebView2 Runtime");
   if(text=="Visual C++ Redistributable x86")return HasUninstallDisplay("Microsoft Visual C++ 2015-2022 Redistributable (x86)")||HasUninstallDisplay("Microsoft Visual C++ 2015-2022 Redistributable");
   if(text=="Proton VPN")return HasUninstallDisplay("Proton VPN")||HasUninstallDisplay("ProtonVPN");
   if(text=="UniKey")return HasUninstallDisplay("UniKey")||File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"UniKey\UniKeyNT.exe"));
   if(text=="UltraViewer")return HasUninstallDisplay("UltraViewer");
  }catch{}
  return false;
 }
 bool HasUninstallDisplay(string needle){
  foreach(var root in new[]{Registry.LocalMachine,Registry.CurrentUser})foreach(var path in new[]{@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"})try{using var k=root.OpenSubKey(path);if(k==null)continue;foreach(var n in k.GetSubKeyNames()){using var sk=k.OpenSubKey(n);var d=sk?.GetValue("DisplayName")?.ToString();if(!string.IsNullOrEmpty(d)&&d.Contains(needle,StringComparison.OrdinalIgnoreCase))return true;}}catch{}
  return false;
 }
 void RefreshStatus(){try{var c=new DriveInfo("C");var (rx,tx)=NetBytes();var now=DateTime.Now;var sec=Math.Max(.1,(now-lastNet).TotalSeconds);var down=(rx-lastRx)/sec/1024/1024;var up=(tx-lastTx)/sec/1024/1024;lastRx=rx;lastTx=tx;lastNet=now;var cpu=Cpu();var mem=Memory();metrics.Text=$"CPU: {cpu,5:F1}%    RAM: {mem.used:F1}/{mem.total:F1} GB    C: {c.AvailableFreeSpace/1073741824.0:F1} GB trống\n↓ {down:F2} MB/s      ↑ {up:F2} MB/s\nUptime: {TimeSpan.FromMilliseconds(Environment.TickCount64):d\\.hh\\:mm}    Process: {Process.GetProcesses().Length}    RDP: {GetRdp()}";}catch{}}
 (ulong rx,ulong tx) NetBytes(){ulong r=0,t=0;foreach(var n in NetworkInterface.GetAllNetworkInterfaces())if(n.OperationalStatus==OperationalStatus.Up){var s=n.GetIPv4Statistics();r+=(ulong)s.BytesReceived;t+=(ulong)s.BytesSent;}return(r,t);} double Cpu(){GetSystemTimes(out var i,out var k,out var u);ulong I=ToU(i),K=ToU(k),U=ToU(u);var sys=(K-lastKernel)+(U-lastUser);var idle=I-lastIdle;lastIdle=I;lastKernel=K;lastUser=U;return sys==0?0:100.0*(sys-idle)/sys;} static ulong ToU(FILETIME f)=>((ulong)f.dwHighDateTime<<32)|f.dwLowDateTime;
 (double used,double total) Memory(){var m=new MEMORYSTATUSEX();m.dwLength=(uint)Marshal.SizeOf<MEMORYSTATUSEX>();GlobalMemoryStatusEx(ref m);double total=m.ullTotalPhys/1073741824.0, avail=m.ullAvailPhys/1073741824.0;return(total-avail,total);}
 static string Safe(string s)=>string.Concat(s.Select(c=>Path.GetInvalidFileNameChars().Contains(c)?'_':c)); static bool Confirm(string s)=>MessageBox.Show(s,"VPS",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes;
 static string? FindChromeExe(){
  var paths=new[]{
   Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"Google\Chrome\Application\chrome.exe"),
   Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),@"Google\Chrome\Application\chrome.exe"),
   Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),@"Google\Chrome\Application\chrome.exe")
  };
  foreach(var p in paths)if(!string.IsNullOrWhiteSpace(p)&&File.Exists(p))return p;
  try{var k=Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe");var v=k?.GetValue(null)?.ToString();if(!string.IsNullOrWhiteSpace(v)&&File.Exists(v))return v;}catch{}
  try{var k=Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe");var v=k?.GetValue(null)?.ToString();if(!string.IsNullOrWhiteSpace(v)&&File.Exists(v))return v;}catch{}
  return null;
 }
 static void Run(string f,string a){try{Process.Start(new ProcessStartInfo(f,a){UseShellExecute=true,Verb="runas"});}catch(Exception ex){MessageBox.Show(ex.Message);}} static int RunWait(string f,string a){try{using var p=Process.Start(new ProcessStartInfo(f,a){UseShellExecute=true,Verb="runas"});if(p==null)return-1;p.WaitForExit();return p.ExitCode;}catch(Exception ex){MessageBox.Show(ex.Message);return-1;}}
 [DllImport("user32.dll")]static extern bool SetForegroundWindow(IntPtr hWnd);[DllImport("kernel32.dll")]static extern bool GetSystemTimes(out FILETIME idle,out FILETIME kernel,out FILETIME user);[DllImport("kernel32.dll")]static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX b);[StructLayout(LayoutKind.Sequential)]struct FILETIME{public uint dwLowDateTime,dwHighDateTime;}[StructLayout(LayoutKind.Sequential,CharSet=CharSet.Auto)]struct MEMORYSTATUSEX{public uint dwLength,dwMemoryLoad;public ulong ullTotalPhys,ullAvailPhys,ullTotalPageFile,ullAvailPageFile,ullTotalVirtual,ullAvailVirtual,ullAvailExtendedVirtual;}
}
